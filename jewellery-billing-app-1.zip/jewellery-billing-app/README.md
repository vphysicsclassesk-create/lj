# Jewellery Shop Billing Web App (PHP + MySQL)

Starter app for Hostinger shared hosting. Features:
- Password-protected dashboard
- Customer details and bill date
- Multiple jewellery line items, purity, gross/net weight, rate per gram, making and stone charges
- Discount and configurable GST percentage
- Recent bills list and print / Save as PDF invoice

## Install on Hostinger
1. In hPanel, create a MySQL database and database user. Give the user privileges on the database.
2. Open phpMyAdmin and import `schema.sql` into that database.
3. Edit `config.php`: database name/user/password, app password, shop name/address/phone.
4. Upload these files to `public_html/jewellery/` using File Manager, FTP, or your Git deployment workflow.
5. Visit `https://your-domain.example/jewellery/login.php` and sign in using `APP_PASSWORD`.
6. Change the default app password before use. Use HTTPS, keep PHP/Hostinger updated, and take regular database backups.

## GitHub deployment
- Create a **private** GitHub repository and upload the project files.
- Never commit real database credentials or your production password. For a public repository, move secrets out of `config.php` into environment variables or a non-public config file.
- Deploy the repository to Hostinger using its Git deployment feature if available on your hosting plan, or upload the files via FTP/File Manager.
- Confirm the deployment target is the intended folder and keep `schema.sql` outside the public web root after installation where practical.

## Important limitations
This is a starter bill register, not a complete GST-compliance or accounting system. Verify the correct tax treatment with your accountant before issuing invoices. It does not yet support stock/inventory, barcode/SKU, purchase bills, returns, payment tracking, user roles, audit logs, or automated backups. Add these before relying on it for full shop operations.
