<?php
declare(strict_types=1);
session_start();

/* Update these values in Hostinger hPanel > PHP configuration or here.
   Do not publish real passwords in a public GitHub repository. */
const DB_HOST = 'localhost';
const DB_NAME = 'YOUR_DATABASE_NAME';
const DB_USER = 'YOUR_DATABASE_USER';
const DB_PASS = 'YOUR_DATABASE_PASSWORD';
const APP_PASSWORD = 'ChangeThisStrongPassword!'; // Change before going live.
const SHOP_NAME = 'Your Jewellery Shop';
const SHOP_ADDRESS = 'Your shop address';
const SHOP_PHONE = 'Your phone number';

function db(): PDO {
    static $pdo = null;
    if (!$pdo) {
        $pdo = new PDO(
            'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',
            DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
             PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
             PDO::ATTR_EMULATE_PREPARES => false]
        );
    }
    return $pdo;
}
function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function logged_in(): bool { return !empty($_SESSION['jewellery_logged_in']); }
function require_login(): void {
    if (!logged_in()) { header('Location: login.php'); exit; }
}
