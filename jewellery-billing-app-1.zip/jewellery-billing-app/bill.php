<?php
require __DIR__.'/config.php';
require_login();
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) { http_response_code(400); exit('Invalid bill ID'); }
$pdo = db();
$s = $pdo->prepare('SELECT * FROM bills WHERE id=?'); $s->execute([$id]); $bill = $s->fetch();
if (!$bill) { http_response_code(404); exit('Bill not found'); }
$s = $pdo->prepare('SELECT * FROM bill_items WHERE bill_id=? ORDER BY id'); $s->execute([$id]); $items = $s->fetchAll();
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($bill['bill_no'])?></title><style>
body{font:14px Arial;color:#111;margin:0;background:#f3f4f6}.paper{background:#fff;max-width:800px;margin:24px auto;padding:32px}.head{text-align:center;border-bottom:2px solid #222;padding-bottom:14px}.meta{display:flex;justify-content:space-between;gap:20px;margin:20px 0}table{border-collapse:collapse;width:100%}th,td{border:1px solid #999;padding:8px;text-align:left}th{background:#f1f5f9}.num{text-align:right}.totals{margin:18px 0 0 auto;width:min(340px,100%)}.totals div{display:flex;justify-content:space-between;padding:5px}.grand{font-weight:bold;border-top:2px solid #222;margin-top:5px;padding-top:9px!important}.actions{max-width:800px;margin:15px auto;display:flex;gap:10px}.btn{padding:10px 14px;background:#1d4ed8;color:white;text-decoration:none;border:0;border-radius:6px;cursor:pointer}@media print{body{background:white}.paper{margin:0;max-width:none;padding:12mm}.actions{display:none}}
</style></head><body><div class="actions"><a class="btn" href="index.php">Back</a><button class="btn" onclick="window.print()">Print / Save PDF</button></div>
<div class="paper"><div class="head"><h1><?=e(SHOP_NAME)?></h1><div><?=e(SHOP_ADDRESS)?></div><div><?=e(SHOP_PHONE)?></div><h2>JEWELLERY BILL</h2></div>
<div class="meta"><div><strong>Bill No:</strong> <?=e($bill['bill_no'])?><br><strong>Date:</strong> <?=e($bill['bill_date'])?></div><div><strong>Customer:</strong> <?=e($bill['customer_name'])?><br><strong>Phone:</strong> <?=e($bill['customer_phone'])?></div></div>
<table><thead><tr><th>#</th><th>Item</th><th>Purity</th><th>Gross wt (g)</th><th>Net wt (g)</th><th>Rate/g</th><th>Making</th><th>Stone</th><th class="num">Amount (₹)</th></tr></thead><tbody>
<?php foreach($items as $i=>$it): ?><tr><td><?=$i+1?></td><td><?=e($it['item_name'])?></td><td><?=e($it['purity'])?></td><td><?=number_format((float)$it['gross_weight'],3)?></td><td><?=number_format((float)$it['net_weight'],3)?></td><td><?=number_format((float)$it['rate_per_gram'],2)?></td><td><?=number_format((float)$it['making_charges'],2)?></td><td><?=number_format((float)$it['stone_charges'],2)?></td><td class="num"><?=number_format((float)$it['line_total'],2)?></td></tr><?php endforeach ?>
</tbody></table><div class="totals"><div><span>Subtotal</span><span>₹<?=number_format((float)$bill['subtotal'],2)?></span></div><div><span>Discount</span><span>− ₹<?=number_format((float)$bill['discount'],2)?></span></div><div><span>GST (<?=number_format((float)$bill['gst_percent'],2)?>%)</span><span>₹<?=number_format((float)$bill['gst_amount'],2)?></span></div><div class="grand"><span>Grand Total</span><span>₹<?=number_format((float)$bill['grand_total'],2)?></span></div></div>
<?php if($bill['notes']): ?><p><strong>Notes:</strong> <?=e($bill['notes'])?></p><?php endif ?><p style="margin-top:40px;text-align:center">Thank you for shopping with us.</p></div></body></html>
