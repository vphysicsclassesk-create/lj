<?php
require __DIR__.'/config.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (hash_equals(APP_PASSWORD, (string)($_POST['password'] ?? ''))) {
        session_regenerate_id(true);
        $_SESSION['jewellery_logged_in'] = true;
        header('Location: index.php'); exit;
    }
    $error = 'Incorrect password.';
}
?>
<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Jewellery Billing Login</title><style>
body{font:16px Arial;background:#f4f5f7;display:grid;place-items:center;min-height:100vh;margin:0}.card{background:white;padding:28px;border-radius:14px;width:min(360px,88vw);box-shadow:0 8px 30px #0001}input,button{box-sizing:border-box;width:100%;padding:12px;margin-top:12px}button{background:#172554;color:white;border:0;border-radius:6px}.err{color:#b91c1c}
</style><div class="card"><h2>Jewellery Billing</h2><p>Sign in to manage shop bills.</p><?php if($error): ?><p class="err"><?=e($error)?></p><?php endif ?><form method="post"><input type="password" name="password" placeholder="App password" required autofocus><button>Sign in</button></form></div></html>
