<?php
require __DIR__.'/config.php';
require_login();
$pdo = db();
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create') {
    try {
        $name = trim((string)($_POST['customer_name'] ?? ''));
        if ($name === '') throw new RuntimeException('Customer name is required.');
        $items = $_POST['items'] ?? [];
        if (!is_array($items) || count($items) < 1) throw new RuntimeException('Add at least one item.');
        $clean = []; $subtotal = 0.0;
        foreach ($items as $item) {
            $itemName = trim((string)($item['name'] ?? ''));
            if ($itemName === '') continue;
            $gross = max(0, (float)($item['gross'] ?? 0));
            $net = max(0, (float)($item['net'] ?? 0));
            $rate = max(0, (float)($item['rate'] ?? 0));
            $making = max(0, (float)($item['making'] ?? 0));
            $stone = max(0, (float)($item['stone'] ?? 0));
            $line = round($net * $rate + $making + $stone, 2);
            $subtotal += $line;
            $clean[] = [$itemName, trim((string)($item['purity'] ?? '')), $gross, $net, $rate, $making, $stone, $line];
        }
        if (!$clean) throw new RuntimeException('Enter a name for at least one item.');
        $discount = max(0, (float)($_POST['discount'] ?? 0));
        $gstPercent = min(100, max(0, (float)($_POST['gst_percent'] ?? 3)));
        $taxable = max(0, $subtotal - $discount);
        $gst = round($taxable * $gstPercent / 100, 2);
        $total = round($taxable + $gst, 2);
        $pdo->beginTransaction();
        $billNo = 'JB-'.date('Ymd').'-'.strtoupper(bin2hex(random_bytes(3)));
        $stmt = $pdo->prepare('INSERT INTO bills (bill_no,bill_date,customer_name,customer_phone,subtotal,discount,gst_percent,gst_amount,grand_total,notes) VALUES (?,?,?,?,?,?,?,?,?,?)');
        $stmt->execute([$billNo, $_POST['bill_date'] ?: date('Y-m-d'), $name, trim((string)($_POST['customer_phone'] ?? '')), $subtotal, $discount, $gstPercent, $gst, $total, trim((string)($_POST['notes'] ?? ''))]);
        $billId = (int)$pdo->lastInsertId();
        $it = $pdo->prepare('INSERT INTO bill_items (bill_id,item_name,purity,gross_weight,net_weight,rate_per_gram,making_charges,stone_charges,line_total) VALUES (?,?,?,?,?,?,?,?,?)');
        foreach ($clean as $r) $it->execute(array_merge([$billId], $r));
        $pdo->commit();
        header('Location: bill.php?id='.$billId); exit;
    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $error = $ex instanceof RuntimeException ? $ex->getMessage() : 'Could not save bill. Check database setup and try again.';
    }
}
$bills = $pdo->query('SELECT id,bill_no,bill_date,customer_name,grand_total FROM bills ORDER BY id DESC LIMIT 50')->fetchAll();
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Jewellery Billing</title>
<style>
*{box-sizing:border-box}body{font:14px Arial,sans-serif;background:#f4f6fa;color:#172033;margin:0}.top{background:#172554;color:white;padding:18px 4%;display:flex;justify-content:space-between;gap:12px;align-items:center}.wrap{max-width:1200px;margin:22px auto;padding:0 16px}.panel{background:#fff;padding:18px;border-radius:12px;margin-bottom:18px;box-shadow:0 2px 12px #0000000b}h2{margin-top:0}input,textarea,select{width:100%;padding:9px;border:1px solid #cbd5e1;border-radius:6px}label{display:block;font-weight:600;margin:8px 0 5px}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.tablewrap{overflow-x:auto}table{border-collapse:collapse;width:100%;min-width:700px}th,td{text-align:left;padding:9px;border-bottom:1px solid #e2e8f0}th{background:#f8fafc}.btn{background:#1d4ed8;color:white;border:0;border-radius:6px;padding:10px 14px;cursor:pointer;text-decoration:none;display:inline-block}.secondary{background:#475569}.danger{color:#b91c1c}.err{background:#fee2e2;padding:10px;border-radius:6px;color:#991b1b}.item input{min-width:90px}.small{font-size:12px;color:#64748b}@media(max-width:700px){.grid{grid-template-columns:1fr 1fr}.top{align-items:flex-start}}
</style></head><body>
<div class="top"><div><strong><?=e(SHOP_NAME)?></strong><div class="small" style="color:#dbeafe">Jewellery Billing System</div></div><a class="btn secondary" href="logout.php">Log out</a></div>
<div class="wrap">
<section class="panel"><h2>Create new bill</h2><?php if($error): ?><p class="err"><?=e($error)?></p><?php endif ?>
<form method="post" id="billform"><input type="hidden" name="action" value="create">
<div class="grid"><div><label>Bill date</label><input type="date" name="bill_date" value="<?=date('Y-m-d')?>" required></div><div><label>Customer name *</label><input name="customer_name" required></div><div><label>Customer phone</label><input name="customer_phone" inputmode="tel"></div></div>
<h3>Items</h3><div class="tablewrap"><table id="items"><thead><tr><th>Item</th><th>Purity</th><th>Gross wt (g)</th><th>Net wt (g)</th><th>Rate/g (₹)</th><th>Making (₹)</th><th>Stone (₹)</th><th></th></tr></thead><tbody id="itemrows"></tbody></table></div>
<p><button type="button" class="btn secondary" onclick="addRow()">+ Add item</button></p>
<div class="grid"><div><label>Discount (₹)</label><input type="number" name="discount" min="0" step=".01" value="0"></div><div><label>GST (%)</label><input type="number" name="gst_percent" min="0" max="100" step=".01" value="3"></div><div><label>Notes</label><input name="notes" placeholder="Optional"></div></div>
<p class="small">Line total = net weight × rate + making charges + stone charges. Confirm the correct GST treatment/rate with your accountant before issuing tax invoices.</p><button class="btn" type="submit">Save bill &amp; print</button>
</form></section>
<section class="panel"><h2>Recent bills</h2><div class="tablewrap"><table><thead><tr><th>Bill No.</th><th>Date</th><th>Customer</th><th>Total</th><th>Action</th></tr></thead><tbody>
<?php foreach($bills as $b): ?><tr><td><?=e($b['bill_no'])?></td><td><?=e($b['bill_date'])?></td><td><?=e($b['customer_name'])?></td><td>₹<?=number_format((float)$b['grand_total'],2)?></td><td><a href="bill.php?id=<?=(int)$b['id']?>">View / Print</a></td></tr><?php endforeach ?>
<?php if(!$bills): ?><tr><td colspan="5">No bills created yet.</td></tr><?php endif ?></tbody></table></div></section>
</div>
<script>
let rowCount=0;
function addRow(){
 const i=rowCount++, tr=document.createElement('tr'); tr.className='item';
 const fields=[['name','Item name','text'],['purity','22K / 18K / 925','text'],['gross','0.000','number'],['net','0.000','number'],['rate','0.00','number'],['making','0.00','number'],['stone','0.00','number']];
 tr.innerHTML=fields.map(([n,p,t])=>`<td><input name="items[${i}][${n}]" placeholder="${p}" ${t==='number'?'type="number" min="0" step="0.001"':'type="text"'} ${n==='name'?'required':''}></td>`).join('')+'<td><button type="button" class="btn secondary" onclick="this.closest(\\'tr\\').remove()">Remove</button></td>';
 document.querySelector('#itemrows').appendChild(tr);
}
addRow();
</script></body></html>
